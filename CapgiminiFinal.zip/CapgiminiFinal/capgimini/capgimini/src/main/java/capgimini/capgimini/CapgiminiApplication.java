package capgimini.capgimini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CapgiminiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapgiminiApplication.class, args);
	}

}
